import os
import time
import traceback
import gestionnaire_pi.resources_rc

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, Qt, QMetaObject, QTimer
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QMessageBox,
    QApplication,
    QFileDialog,
)
from qgis.PyQt.QtGui import QMovie
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsApplication,
    QgsProcessingFeedback,
    QgsTask,
    QgsMessageLog,
    Qgis,
    QgsSettings,
)
from qgis import processing
from gestionnaire_pi.settings.manager import SettingsManager

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "main_dockwidget.ui")
)


class CreateLotTask(QgsTask):
    def __init__(self, description, alg_id, params, dockwidget):
        super().__init__(description, QgsTask.CanCancel)
        self.alg_id = alg_id
        self.params = params
        self.dockwidget = dockwidget
        self.feedback = QgsProcessingFeedback()
        self.start_time = None
        self.errorMessage = None

        QgsMessageLog.logMessage(
            f"[GestionnairePi] CreateLotTask init: {description}",
            tag="GestionnairePi",
            level=Qgis.Warning,
        )

from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer

class CreateLotTask(QgsTask):
    def __init__(self, description, alg_id, params, dockwidget):
        # On ne met qu’un seul argument : la description
        super().__init__(description)
        self.alg_id = alg_id
        self.params = params
        self.dockwidget = dockwidget
        self.feedback = QgsProcessingFeedback()
        self.start_time = None
        self.errorMessage = None

    def run(self):
        """
        Exécuté en arrière-plan : on ne fait QUE le calcul.
        """
        self.start_time = time.time()
        QgsMessageLog.logMessage(
            "▶ CreateLotTask.run() début",
            tag="GestionnairePi", level=Qgis.Warning
        )
        try:
            # Exécution sans chargement de couches
            processing.run(self.alg_id, self.params, feedback=self.feedback)
            return True
        except Exception as e:
            self.errorMessage = str(e)
            QgsMessageLog.logMessage(
                f"✖ CreateLotTask.run() exception : {e}",
                tag="GestionnairePi", level=Qgis.Critical
            )
            return False

    def finished(self, result):
        """
        Exécuté dans le thread UI : on ferme le GIF,
        on recharge les résultats, puis on affiche le temps
        au format MM:SS à la fin.
        """
        QgsMessageLog.logMessage(
            f"▶ CreateLotTask.finished() result={result}",
            tag="GestionnairePi", level=Qgis.Warning
        )

        # 1) Fermer le GIF
        if hasattr(self.dockwidget, "progress_dialog"):
            QMetaObject.invokeMethod(
                self.dockwidget.progress_dialog,
                "close",
                Qt.QueuedConnection
            )

        # 2) En cas d’erreur, on stoppe ici
        if not result:
            QMessageBox.critical(
                self.dockwidget,
                "Erreur durant le traitement",
                self.errorMessage or "Erreur inconnue"
            )
            return

        # 3) Charger les couches de sortie en toute sécurité
        processing.runAndLoadResults(self.alg_id, self.params)

        # 4) Calculer et formater la durée
        elapsed = time.time() - self.start_time
        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)
        time_str = f"{minutes:02d}min {seconds:02d}s"

        # 5) Log final
        QgsMessageLog.logMessage(
            f"[GestionnairePi] ✔ Traitement terminé en {time_str}",
            tag="GestionnairePi", level=Qgis.Warning
        )

        # 6) Message utilisateur avec le temps en dernier
        QMessageBox.information(
            self.dockwidget,
            "Succès",
            f"Création du lot P.I. terminée et résultats chargés.\n\nDurée : {time_str}"
        )
        
class GestionnairePiDockWidget(QtWidgets.QDockWidget, FORM_CLASS):
    closingPlugin = pyqtSignal()
    _task_signals_connected = False
    _layers_signals_connected = False

    def __init__(self, plugin):
        super().__init__(None)
        self.setupUi(self)
        self.plugin = plugin
        self.settings = SettingsManager()
        self.current_color = self.settings.get_color()
        self.current_task = None  # <— on initialise l’attribut qui contiendra la tâche

        # 0) Veiller à avoir au moins 1 thread de processing
        qs = QgsSettings()
        threads = qs.value("processing/threads", 1, type=int)
        if threads < 1:
            qs.setValue("processing/threads", 1)
            QgsMessageLog.logMessage(
                "[GestionnairePi] processing/threads était à 0 → réglé à 1",
                tag="GestionnairePi",
                level=Qgis.Warning,
            )

        # 1) Connexion unique aux signaux du TaskManager
        if not GestionnairePiDockWidget._task_signals_connected:
            tm = QgsApplication.taskManager()
            tm.allTasksFinished.connect(self._onAllTasksFinished)
            GestionnairePiDockWidget._task_signals_connected = True

        # 2) Connexion unique aux signaux de changement de couches
        proj = QgsProject.instance()
        if not GestionnairePiDockWidget._layers_signals_connected:
            proj.layersAdded.connect(self._on_layers_changed)
            proj.layersWillBeRemoved.connect(self._on_layers_changed)
            GestionnairePiDockWidget._layers_signals_connected = True

        # 3) Préremplissage initial
        self.populate_layer_combos()
        self.populate_creation_lot_combos()

        # 4) Connexions UI…
        self.btn_creation_lot.clicked.connect(self.show_creation_lot_menu)
        self.btn_annexe6.clicked.connect(self.show_annexe6_menu)
        self.btn_parametres.clicked.connect(self.show_settings)

        self.btn_annexe6_retour.clicked.connect(self.show_main_menu)
        self.btn_browse_folder.clicked.connect(self.select_output_folder)
        self.btn_annexe6_lancer.clicked.connect(self.run_annexe6_from_ui)
        self.combo_georef.addItems(["", "Avec X C L F"])

        self.selected_line_layers = []
        self.btn_select_line_layers.clicked.connect(self.select_line_layers_dialog)
        self.btn_retour_creation_lot.clicked.connect(self.show_main_menu)
        self.btn_browse_output.clicked.connect(self.select_output_folder_lot)
        self.btn_browse_styles.clicked.connect(self.select_styles_folder)
        self.btn_lancer_creation_lot.clicked.connect(self.run_creation_lot)

        self.btn_browse_default_output.clicked.connect(self.select_default_output_folder)
        self.btn_browse_default_styles.clicked.connect(self.select_default_styles_folder)
        self.btn_save_settings.clicked.connect(self.save_settings)
        self.btn_param_retour.clicked.connect(self.show_main_menu)

        if self.combo_theme:
            self.combo_theme.currentTextChanged.connect(self.apply_theme)

        self.load_settings()

    # ─── gestion des logs du Task Manager ─────────────────────────

    def _onAllTasksFinished(self):
        QgsMessageLog.logMessage(
            "[GestionnairePi] ► Toutes les tâches sont terminées",
            tag="GestionnairePi",
            level=Qgis.Warning,
        )

    # ─── mise à jour conditionnelle des combos ───────────────────

    def _on_layers_changed(self, *args):
        current = self.stackedWidget.currentWidget()
        if current == self.page_annexe6:
            self.populate_layer_combos()
        elif current == self.page_creation_lot:
            self.populate_creation_lot_combos()

    # ─── peuplement des combos ────────────────────────────────────

    def populate_layer_combos(self):
        self.combo_troncons.clear()
        self.combo_zones.clear()
        self.combo_folios.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                geom = QgsWkbTypes.geometryType(layer.wkbType())
                if geom == QgsWkbTypes.LineGeometry:
                    self.combo_troncons.addItem(layer.name())
                elif geom == QgsWkbTypes.PolygonGeometry:
                    self.combo_zones.addItem(layer.name())
                    self.combo_folios.addItem(layer.name())

    def populate_creation_lot_combos(self):
        self.combo_emprises.clear()
        self.combo_emprises.setObjectName("comboEmprises")
        self.combo_lineaires_me.clear()
        self.combo_lineaires_me.setObjectName("comboLineairesME")
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                geom = QgsWkbTypes.geometryType(layer.wkbType())
                if geom == QgsWkbTypes.PolygonGeometry:
                    self.combo_emprises.addItem(layer.name())
                elif geom == QgsWkbTypes.LineGeometry:
                    self.combo_lineaires_me.addItem(layer.name())

    # ─── navigation & actions UI ─────────────────────────────────

    def show_main_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_main_menu)

    def show_annexe6_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_annexe6)
        self.populate_layer_combos()
        self.line_output_folder.setText(self.settings.get_output_folder())

    def show_creation_lot_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_creation_lot)
        self.populate_creation_lot_combos()
        self.line_output.setText(self.settings.get_output_folder())
        self.line_styles.setText(self.settings.get_styles_folder())

    def select_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier de sortie")
        if folder:
            self.line_output_folder.setText(folder)

    def select_output_folder_lot(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier de sortie")
        if folder:
            self.line_output.setText(folder)

    def run_annexe6_from_ui(self):
        from gestionnaire_pi.core.annexe6.controller import Annexe6Processor
        proc = Annexe6Processor(self.plugin.iface)
        proc.run_custom(
            self.combo_troncons.currentText(),
            self.combo_zones.currentText(),
            self.combo_folios.currentText(),
            self.line_output_folder.text(),
        )

    def run_creation_lot(self):
        import random
        n = random.randint(1,4)
        
        self.progress_dialog = QDialog(self)
        self.progress_dialog.setWindowTitle("Traitement en cours")
        self.progress_dialog.setWindowFlags(
            self.progress_dialog.windowFlags() | Qt.WindowStaysOnTopHint
        )
        layout = QVBoxLayout(self.progress_dialog)
        movie = QMovie(f":/plugins/gestionnaire_pi/resources/loading_{n}.gif")
        label_gif = QLabel(self.progress_dialog)
        label_gif.setMovie(movie)
        movie.start()
        layout.addWidget(label_gif, alignment=Qt.AlignCenter)
        label_text = QLabel(
            "Le traitement est en cours…\nVeuillez patienter.", self.progress_dialog
        )
        label_text.setAlignment(Qt.AlignCenter)
        layout.addWidget(label_text)

        self.progress_dialog.show()
        QTimer.singleShot(100, self._start_sync_processing)

    def _start_sync_processing(self):
        params = {
            "insee": self.line_insee.text(),
            "emprises": self._layer_by_name(self.combo_emprises.currentText()),
            "lineaires": self.selected_line_layers,
            "lineaires_me": self._layer_by_name(self.combo_lineaires_me.currentText()),
            "inclure_classe_b": self.inclure_classe_b.isChecked(),
            "georeferencement": self.combo_georef.currentIndex(),
            "dossier_sortie": self.line_output.text(),
            "dossier_styles": self.line_styles.text(),
        }
        alg_id = "gestionnaire_pi_models:Principale"

        # <— On conserve la tâche dans un attribut pour éviter sa collecte GC
        self.current_task = CreateLotTask("Création lot P.I.", alg_id, params, self)
        QgsApplication.taskManager().addTask(self.current_task)

    def _layer_by_name(self, name):
        return QgsProject.instance().mapLayersByName(name)[0] if name else None

    def show_settings(self):
        self.stackedWidget.setCurrentWidget(self.page_parametres)

    def load_settings(self):
        self.line_default_output.setText(self.settings.get_output_folder())
        self.line_default_styles.setText(self.settings.get_styles_folder())
        self.check_logs.setChecked(self.settings.get_log_detail())
        self.current_color = self.settings.get_color()
        self.setStyleSheet(f"background-color: {self.current_color.name()};")
        if hasattr(self, "label_color"):
            self.label_color.setStyleSheet(
                f"background-color: {self.current_color.name()}"
            )
        if self.combo_theme:
            theme = self.settings.get_theme()
            idx = self.combo_theme.findText(theme)
            self.combo_theme.setCurrentIndex(idx if idx >= 0 else 0)
            self.apply_theme(theme)

    def save_settings(self):
        self.settings.set_output_folder(self.line_default_output.text())
        self.settings.set_styles_folder(self.line_default_styles.text())
        self.settings.set_log_detail(self.check_logs.isChecked())
        self.settings.set_color(self.current_color)
        if self.combo_theme:
            self.settings.set_theme(self.combo_theme.currentText())

    def select_default_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier de sortie")
        if folder:
            self.line_default_output.setText(folder)

    def select_default_styles_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier des styles")
        if folder:
            self.line_default_styles.setText(folder)

    def select_styles_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier des styles")
        if folder:
            self.line_styles.setText(folder)

    def apply_theme(self, theme: str):
        """
        Applique le thème choisi à TOUTE l’application (dock + fenêtres pop‑up),
        y compris la partie déroulante des QComboBox.
        """
        styles = {

            # ────────────────────────── THÈME CLAIR ──────────────────────────
            "Thème clair": """
                /* --- widgets fixes -------------------------------------------------- */
                QDockWidget, QWidget     { background-color: #f0f0f0; color: #000; }
                QLineEdit, QComboBox,
                QTextEdit                { background-color: #fff;    color: #000;
                                            border: 1px solid #ccc; }
                QPushButton, QTreeWidget { background-color: #e0e0e0; color: #000; }
                QCheckBox                { color: #000; }

                QComboBox QListView {
                    background-color: #ffffff;
                    color: #000000;
                }
            """,

            # ───────────────────────── THÈME SOMBRE ─────────────────────────
            "Thème sombre": """
                QDockWidget, QWidget     { background-color: #2e2e2e; color: #ffffff; }
                QLineEdit, QComboBox,
                QTextEdit                { background-color: #3c3c3c; color: #ffffff;
                                            border: 1px solid #555555; }
                QPushButton, QTreeWidget { background-color: #444444; color: #ffffff; }
                QCheckBox                { color: #ffffff; }

                QComboBox QListView {
                    background-color: #333333;
                    color: #dddddd;
                }
            """,

            # ──────────────────────── THÈME RATON LAVEUR ────────────────────────
            "Thème raton laveur": """
                QDockWidget, QWidget     { background-color: #0051a2; color: #76b855; }
                QLineEdit, QComboBox,
                QTextEdit                { background-color: #009dc5; color: #0d0d0d;
                                            border: 1px solid #009dc5; }
                QPushButton              { background-color: #009dc5; color: #0d0d0d; }
                QTreeWidget              { background-color: #ff0000; color: #00ff00; }
                QCheckBox                { color: #76b855; }

                QComboBox QListView {
                    background-color: #76b855;
                    color: #000000;
                }
            """,
        }
        self.setStyleSheet(styles.get(theme, styles["Thème clair"]))

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def select_line_layers_dialog(self):
        layers = [
            layer for layer in QgsProject.instance().mapLayers().values()
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == QgsWkbTypes.LineGeometry
        ]

        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Sélectionner les linéaires")
        layout = QtWidgets.QVBoxLayout(dialog)

        checkboxes = []
        for layer in layers:
            cb = QtWidgets.QCheckBox(layer.name())
            cb.setChecked(layer.name() in [l.name() for l in self.selected_line_layers])
            layout.addWidget(cb)
            checkboxes.append((cb, layer))

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(dialog.accept)
        btns.rejected.connect(dialog.reject)

        if dialog.exec_():
            self.selected_line_layers = [layer for cb, layer in checkboxes if cb.isChecked()]
            count = len(self.selected_line_layers)
            self.line_selected_layers.setText(f"{count} couche(s) sélectionnée(s)" if count else "Aucune couche sélectionnée")
