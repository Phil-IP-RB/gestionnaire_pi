# --- Standard library -------------------------------------------------
import os
import re, time

# --- QGIS / Qt --------------------------------------------------------
from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, Qt, QMetaObject, QTimer, QDir
from qgis.PyQt.QtGui import QMovie

from qgis.PyQt.QtWidgets import (
    QFileDialog,
    QLabel,
    QDialog,
    QVBoxLayout,
    QMessageBox,
)
from qgis.core import (
    QgsApplication, QgsMessageLog, QgsProcessingAlgRunnerTask,
    QgsProcessingContext, QgsProcessingFeedback, QgsProject,
    QgsRasterLayer, QgsSettings, QgsVectorLayer,
    QgsWkbTypes, Qgis,
)
from qgis import processing

# --- Plugin local -----------------------------------------------------
from gestionnaire_pi.settings.manager import SettingsManager
import gestionnaire_pi.resources_rc

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "main_dockwidget.ui")
)

class TimingFeedback(QgsProcessingFeedback):
    _re_start = re.compile(r"^Running (.+)")
    _re_end   = re.compile(r"^Algorithm '([^']+)' finished")

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._t0: dict[str, float] = {}
        self.times: dict[str, float] = {}

    # ---------- traitement commun ----------
    def _handle_msg(self, msg: str):
        if m := self._re_start.match(msg):
            self._t0[m.group(1)] = time.perf_counter()
        elif m := self._re_end.match(msg):
            algo = m.group(1)
            if algo in self._t0:
                self.times[algo] = time.perf_counter() - self._t0.pop(algo, 0.0)

    # ---------- méthodes redirigées ----------
    def info(self, text):                # ← ajout indispensable
        self._handle_msg(text)
        QgsMessageLog.logMessage(f"[GestionnairePi] ► {text}",
                                 "Traitement", Qgis.Info)
        super().info(text)

    def pushCommandInfo(self, msg):
        self._handle_msg(msg)
        super().pushCommandInfo(msg)

    def pushDebugInfo(self, msg):
        self._handle_msg(msg)
        super().pushDebugInfo(msg)


class GestionnairePiDockWidget(QtWidgets.QDockWidget, FORM_CLASS):
    """Dock principal du plugin Gestionnaire P.I."""

    closingPlugin = pyqtSignal()
    _task_signals_connected = False
    _layers_signals_connected = False

    # ────────────────────────────── INIT ──────────────────────────────
    def __init__(self, plugin):
        super().__init__(None)
        self.setupUi(self)
        self.plugin = plugin
        self.settings = SettingsManager()
        self.current_color = self.settings.get_color()

        self.current_task: QgsProcessingAlgRunnerTask | None = None
        self.current_context: QgsProcessingContext | None = None
        self._task_start_time: float | None = None

        # Au moins 1 thread Processing
        qs = QgsSettings()
        if qs.value("processing/threads", 1, type=int) < 1:
            qs.setValue("processing/threads", 1)

        # Connexions uniques (TaskManager & Project)
        if not GestionnairePiDockWidget._task_signals_connected:
            QgsApplication.taskManager().allTasksFinished.connect(self._on_all_tasks_finished)
            GestionnairePiDockWidget._task_signals_connected = True

        if not GestionnairePiDockWidget._layers_signals_connected:
            prj = QgsProject.instance()
            prj.layersAdded.connect(self._on_layers_changed)
            prj.layersWillBeRemoved.connect(self._on_layers_changed)
            GestionnairePiDockWidget._layers_signals_connected = True

        # Préremplissage UI
        self.populate_layer_combos()
        self.populate_creation_lot_combos()

        # Connexions UI
        self.btn_creation_lot.clicked.connect(self.show_creation_lot_menu)
        self.btn_annexe6.clicked.connect(self.show_annexe6_menu)
        self.btn_parametres.clicked.connect(self.show_settings)

        self.btn_annexe6_retour.clicked.connect(self.show_main_menu)
        self.btn_browse_folder.clicked.connect(self.select_output_folder)
        self.btn_annexe6_lancer.clicked.connect(self.run_annexe6_from_ui)
        self.combo_georef.addItems(["", "Avec X C L F"])

        self.selected_line_layers = []
        self.btn_select_line_layers.clicked.connect(self.select_line_layers_dialog)
        self.btn_retour_creation_lot.clicked.connect(self.show_main_menu)
        self.btn_browse_output.clicked.connect(self.select_output_folder_lot)
        self.btn_browse_styles.clicked.connect(self.select_styles_folder)
        self.btn_lancer_creation_lot.clicked.connect(self.run_creation_lot)

        self.btn_browse_default_output.clicked.connect(self.select_default_output_folder)
        self.btn_browse_default_styles.clicked.connect(self.select_default_styles_folder)
        self.btn_save_settings.clicked.connect(self.save_settings)
        self.btn_param_retour.clicked.connect(self.show_main_menu)

        if self.combo_theme:
            self.combo_theme.currentTextChanged.connect(self.apply_theme)

        self.load_settings()

    # ─── Logs TaskManager ─────────────────────────────────────────────
    def _on_all_tasks_finished(self):
        QgsMessageLog.logMessage("[GestionnairePi] ► Toutes les tâches terminées", "GestionnairePi", Qgis.Info)

    # ─── MAJ combos selon pages ──────────────────────────────────────
    def _on_layers_changed(self, *args):
        page = self.stackedWidget.currentWidget()
        if page == self.page_annexe6:
            self.populate_layer_combos()
        elif page == self.page_creation_lot:
            self.populate_creation_lot_combos()

    # ─── Peuplement combos ───────────────────────────────────────────
    def populate_layer_combos(self):
        self.combo_troncons.clear()
        self.combo_zones.clear()
        self.combo_folios.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                geom = QgsWkbTypes.geometryType(lyr.wkbType())
                if geom == QgsWkbTypes.LineGeometry:
                    self.combo_troncons.addItem(lyr.name())
                elif geom == QgsWkbTypes.PolygonGeometry:
                    self.combo_zones.addItem(lyr.name())
                    self.combo_folios.addItem(lyr.name())

    def populate_creation_lot_combos(self):
        self.combo_emprises.clear()
        self.combo_lineaires_me.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                geom = QgsWkbTypes.geometryType(lyr.wkbType())
                if geom == QgsWkbTypes.PolygonGeometry:
                    self.combo_emprises.addItem(lyr.name())
                elif geom == QgsWkbTypes.LineGeometry:
                    self.combo_lineaires_me.addItem(lyr.name())

    # ─── Navigation UI ───────────────────────────────────────────────
    def show_main_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_main_menu)

    def show_annexe6_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_annexe6)
        self.populate_layer_combos()
        self.line_output_folder.setText(self.settings.get_output_folder())

    def show_creation_lot_menu(self):
        self.stackedWidget.setCurrentWidget(self.page_creation_lot)
        self.populate_creation_lot_combos()
        self.line_output.setText(self.settings.get_output_folder())
        self.line_styles.setText(self.settings.get_styles_folder())

    # ─── Sélecteurs simples ─────────────────────────────────────────
    def select_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Dossier de sortie")
        if folder:
            self.line_output_folder.setText(folder)

    def select_output_folder_lot(self):
        folder = QFileDialog.getExistingDirectory(self, "Dossier de sortie")
        if folder:
            self.line_output.setText(folder)

    # ─── ANNEXE 6 ────────────────────────────────────────────────────
    def run_annexe6_from_ui(self):
        from gestionnaire_pi.core.annexe6.controller import Annexe6Processor
        Annexe6Processor(self.plugin.iface).run_custom(
            self.combo_troncons.currentText(),
            self.combo_zones.currentText(),
            self.combo_folios.currentText(),
            self.line_output_folder.text(),
        )

    # ─── CRÉATION LOT P.I. ───────────────────────────────────────────
    def run_creation_lot(self):
        QgsMessageLog.logMessage(
                "[GestionnairePi] Départ du traitement",
                tag="GestionnairePi", level=Qgis.Info
            )
        # Validation minimale
        missing = []
        codes = [c.strip() for c in self.line_insee.text().split(";") if c.strip()]
        for c in codes:
            if not (c.isdigit() and len(c) == 5):
                missing.append(f"Code INSEE invalide : « {c} »")
        if not self._layer_by_name(self.combo_emprises.currentText()):
            missing.append("couche d’emprises")
        if not self.selected_line_layers:
            missing.append("couche(s) linéaire(s)")
        if not self._layer_by_name(self.combo_lineaires_me.currentText()):
            missing.append("couche de linéaires ME")

        if missing:
            QMessageBox.warning(self, "Champs manquants", ", ".join(missing))
            return

        self._show_progress_dialog()
        QTimer.singleShot(0, self._start_processing_task)

    # ─── Lancement de la tâche Processing ────────────────────────────
    def _start_processing_task(self):
        self._task_start_time = time.time()

        params = {
            "insee": self.line_insee.text(),
            "emprises": self._layer_by_name(self.combo_emprises.currentText()),
            "lineaires": self.selected_line_layers,
            "lineaires_me": self._layer_by_name(self.combo_lineaires_me.currentText()),
            "inclure_classe_b": self.inclure_classe_b.isChecked(),
            "georeferencement": self.combo_georef.currentIndex(),
            "dossier_sortie": self.line_output.text(),
            "dossier_styles": self.line_styles.text(),
        }

        alg_id = "gestionnaire_pi_models:Principale"
        alg = QgsApplication.processingRegistry().algorithmById(alg_id)
        if alg is None:
            self._close_progress_dialog()
            QMessageBox.critical(self, "Erreur", f"Algorithme introuvable : {alg_id}")
            return
        
        QgsMessageLog.logMessage(
            f"[GestionnairePi] ► Exécution algorithme {alg.id()} – {alg.displayName()}",
            "GestionnairePi", Qgis.Info
        )

        context = QgsProcessingContext()
        context.setProject(QgsProject.instance())
        feedback = TimingFeedback()          

        task = QgsProcessingAlgRunnerTask(alg, params, context, feedback)
        self.current_task, self.current_context = task, context

        # 4) Callback exécuté sur le thread principal
        def _on_executed(success: bool, results: dict[str, object]):
            self._close_progress_dialog()
            if not success:
                QMessageBox.critical(self, "Erreur", feedback.text() or "Échec du traitement.")
                return

            proj         = QgsProject.instance()
            child        = results.get("CHILD_RESULTS", {})  
            loaded       = 0

            # ───────── 1.  couches vecteur finales (déjà stylées) ─────────
            keep_ids = [
                child.get("native:loadlayer_1", {}).get("OUTPUT"),  # linéaires
                child.get("native:loadlayer_2", {}).get("OUTPUT"),  # folios
                child.get("native:loadlayer_3", {}).get("OUTPUT"),  # zone détection
            ]

            for lid in filter(None, keep_ids):
                # ② on essaie d’abord de récupérer la couche que le modèle a en mémoire,
                #    sinon on regarde dans le projet, sinon on recharge depuis le fichier.
                layer = context.takeResultLayer(lid) or proj.mapLayer(lid)
                if not layer:
                    path = child.get("native:loadlayer_1", {}).get("INPUT") \
                           if lid == keep_ids[0] else \
                           child.get("native:loadlayer_2", {}).get("INPUT") \
                           if lid == keep_ids[1] else \
                           child.get("native:loadlayer_3", {}).get("INPUT")
                    if path:
                        layer = QgsVectorLayer(path, QgsPathResolver().fileName(path), "ogr")

                if layer and layer.isValid():
                    proj.addMapLayer(layer)
                    loaded += 1

            # ───────── 2.  le CSV (table) ─────────
            csv_path = child.get("native:savefeatures_5", {}).get("FILE_PATH")
            if csv_path and os.path.exists(csv_path):
                uri   = f"file:///{csv_path}?delimiter=,&detectTypes=no&geomType=none"
                table = QgsVectorLayer(uri, "export_folios", "delimitedtext")
                if table.isValid():
                    proj.addMapLayer(table)
                    loaded += 1

            # ───────── 4.  message récapitulatif ─────────
            # TOP N étapes les plus lentes
            slowest = sorted(feedback.times.items(), key=lambda i: i[1], reverse=True)[:5]
            if slowest:
                toplist = "\n".join(f"• {aid} : {t:.1f} s" for aid, t in slowest)
                toplist = f"\n\nÉtapes les plus longues :\n{toplist}"
            else:
                toplist = ""

            # Journal complet dans le panneau « Journaux »
            for k, v in feedback.times.items():
                QgsMessageLog.logMessage(f"{k}: {v:.2f} s",
                                         "GestionnairePi",
                                         Qgis.Warning)

            d = int(time.time() - self._task_start_time)
            QMessageBox.information(
                self,
                "Succès",
                f"{loaded} couche(s) chargée(s).\n"
                f"Durée : {d//60:02} min {d%60:02} s"
            )

        task.executed.connect(_on_executed)
        QgsApplication.taskManager().addTask(task)

    # ─── Progress dialog ─────────────────────────────────────────────
    def _show_progress_dialog(self):
        import random
        n = random.randint(1, 4)

        self.progress_dialog = QDialog(self)
        self.progress_dialog.setWindowTitle("Traitement en cours")
        self.progress_dialog.setWindowModality(Qt.ApplicationModal)
        self.progress_dialog.setWindowFlags(
            self.progress_dialog.windowFlags() | Qt.WindowStaysOnTopHint
        )

        layout = QVBoxLayout(self.progress_dialog)
        movie = QMovie(f":/plugins/gestionnaire_pi/resources/img/loading_{n}.gif")
        label_gif = QLabel(self.progress_dialog)

        if movie.isValid():
            label_gif.setMovie(movie)
            movie.start()
        else:
            label_gif.setText("…")
        layout.addWidget(label_gif, alignment=Qt.AlignCenter)

        label_text = QLabel("Le traitement est en cours…\nVeuillez patienter.", self.progress_dialog)
        label_text.setAlignment(Qt.AlignCenter)
        layout.addWidget(label_text)

        self.progress_dialog.show()

    def _close_progress_dialog(self):
        if hasattr(self, "progress_dialog"):
            dlg = self.progress_dialog
            QMetaObject.invokeMethod(dlg, "close", Qt.QueuedConnection)
            QMetaObject.invokeMethod(dlg, "deleteLater", Qt.QueuedConnection)
            del self.progress_dialog

    # ─── Utilitaires ─────────────────────────────────────────────────
    def _layer_by_name(self, name: str | None) -> QgsVectorLayer | None:
        if not name:
            return None
        layers = QgsProject.instance().mapLayersByName(name)
        return layers[0] if layers else None

    # ─── PARAMÈTRES & THÈME ───────────────────────────────────────────

    def show_settings(self):
        self.stackedWidget.setCurrentWidget(self.page_parametres)

    def load_settings(self):
        self.line_default_output.setText(self.settings.get_output_folder())
        self.line_default_styles.setText(self.settings.get_styles_folder())
        self.check_logs.setChecked(self.settings.get_log_detail())
        self.current_color = self.settings.get_color()
        self.setStyleSheet(f"background-color: {self.current_color.name()};")
        if hasattr(self, "label_color"):
            self.label_color.setStyleSheet(
                f"background-color: {self.current_color.name()}"
            )
        if self.combo_theme:
            theme = self.settings.get_theme()
            idx = self.combo_theme.findText(theme)
            self.combo_theme.setCurrentIndex(idx if idx >= 0 else 0)
            self.apply_theme(theme)

    def save_settings(self):
        self.settings.set_output_folder(self.line_default_output.text())
        self.settings.set_styles_folder(self.line_default_styles.text())
        self.settings.set_log_detail(self.check_logs.isChecked())
        self.settings.set_color(self.current_color)
        if self.combo_theme:
            self.settings.set_theme(self.combo_theme.currentText())

    def select_default_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier de sortie")
        if folder:
            self.line_default_output.setText(folder)

    def select_default_styles_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier des styles")
        if folder:
            self.line_default_styles.setText(folder)

    def select_styles_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier des styles")
        if folder:
            self.line_styles.setText(folder)

    def apply_theme(self, theme: str):
        """
        Applique le thème choisi à toute l’application.
        """
        styles = {
            # ────────────────────────── THÈME CLAIR ──────────────────────────
            "Thème clair": """
                /* --- widgets fixes -------------------------------------------------- */
                QDockWidget, QWidget     { background-color: #f0f0f0; color: #000; }
                QLineEdit, QComboBox,
                QTextEdit                { background-color: #fff;    color: #000;
                                            border: 1px solid #ccc; }
                QPushButton, QTreeWidget { background-color: #e0e0e0; color: #000; }
                QCheckBox                { color: #000; }

                QComboBox QListView {
                    background-color: #ffffff;
                    color: #000000;
                }
            """,

            # ───────────────────────── THÈME SOMBRE ─────────────────────────
            "Thème sombre": """
                QDockWidget, QWidget     { background-color: #2e2e2e; color: #ffffff; }
                QLineEdit, QComboBox,
                QTextEdit                { background-color: #3c3c3c; color: #ffffff;
                                            border: 1px solid #555555; }
                QPushButton, QTreeWidget { background-color: #444444; color: #ffffff; }
                QCheckBox                { color: #ffffff; }

                QComboBox QListView {
                    background-color: #333333;
                    color: #dddddd;
                }
            """,

            # ──────────────────────── THÈME RATON LAVEUR ────────────────────────
            "Thème raton laveur": """
                QWidget#page_main_menu, QWidget#page_creation_lot, QWidget#page_annexe6 , QWidget#page_creation_lot, QWidget#page_parametres {
                    background-color: #0051a2 ;
                    background-image: url(:/plugins/gestionnaire_pi/resources/img/racoon_256.png);
                    background-repeat: no-repeat ;
                    background-position: bottom center ;
                    background-size: cover ;
                }
                QDockWidget, QWidget     { background-color: #0051a2 ; color: #76b855; }
                QLineEdit, QComboBox, QTextEdit {background-color: #009dc5 ;color: #000 ; border: 1px solid #009dc5 ; }
                QPushButton {background-color: #009dc5;color: #0d0d0d ; }
                QTreeWidget {background-color: #ff0000;color: #00ff00 ; }
                QCheckBox {color: #76b855;}
                QComboBox QListView {background-color: #76b855 ; color: #0d0d0d;}
            """,
        }
        self.setStyleSheet(styles.get(theme, styles["Thème clair"]))

    # ─── FERMETURE ────────────────────────────────────────────────────

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    # ─── DIALOGUE DE SÉLECTION DES LINÉAIRES ──────────────────────────
    def select_line_layers_dialog(self):
        layers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                  if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == QgsWkbTypes.LineGeometry]

        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Sélectionner les linéaires")
        lay = QtWidgets.QVBoxLayout(dlg)

        cbs = []
        for lyr in layers:
            cb = QtWidgets.QCheckBox(lyr.name())
            cb.setChecked(lyr.name() in [l.name() for l in self.selected_line_layers])
            lay.addWidget(cb)
            cbs.append((cb, lyr))

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        lay.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)

        if dlg.exec_():
            self.selected_line_layers = [lyr for cb, lyr in cbs if cb.isChecked()]
            n = len(self.selected_line_layers)
            self.line_selected_layers.setText(f"{n} couche(s) sélectionnée(s)" if n else "Aucune couche sélectionnée")

    # ─── Fermeture ───────────────────────────────────────────────────
    def closeEvent(self, e):
        self.closingPlugin.emit()
        e.accept()
